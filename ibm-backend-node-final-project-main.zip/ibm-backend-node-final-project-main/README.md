<h1 align="center"> IBM Full Stack Software Developer Certificate <br> Developing Back-End Apps with Node.js and Express </h1>

## Book Review Application

This is the final project within the course, "Developing Back-End Apps with Node.js and Express" in the IBM Full Stack Software Developer Certificate. The objective of this project is to use the provided boilerplate code to create a server-side online book review application and integrate it with a secure REST API server which will use authentication at session level using JWT.

More information about the course can be found [here](https://www.coursera.org/learn/developing-backend-apps-with-nodejs-and-express/).
